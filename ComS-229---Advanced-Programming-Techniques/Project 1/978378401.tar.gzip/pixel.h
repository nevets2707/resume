/** 
 *
 * Stuct for the pixel
 *


 */

#ifndef _PIXEL_H
#define _PIXEL_H
typedef struct pixel_s
{
	unsigned char red;
	unsigned char green;
	unsigned char blue;
	unsigned char alpha;

} pixel;

#endif




