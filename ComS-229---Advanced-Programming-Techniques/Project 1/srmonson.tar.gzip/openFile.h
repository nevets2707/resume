


#ifndef _OPENFILE_H
#define _OPENFILE_H
#include "image.h"
image* open(char* file);

#endif

