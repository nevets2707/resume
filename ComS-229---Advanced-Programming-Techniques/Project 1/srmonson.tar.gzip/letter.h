
#ifndef __LETTER_H_
#define __LETTER_H_

typedef struct letter_s
{
	char value;
	int x;
	int y;
	int w;
	int h;

}letter;

#endif
