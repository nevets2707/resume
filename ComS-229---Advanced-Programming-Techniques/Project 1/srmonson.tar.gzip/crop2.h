#include "image.h"

#ifndef __CROP_H_
#define __CROP_H_
image* crop(char* file, int x, int y, int w, int h);
#endif
